HOMECARE — WHITE LABEL WORKSHOP
HA-14 · Repairable fold-flat drying rack · Revision A0
Authored 2026-11-04

Industrial-design proposals. Dimensioned exterior mockups, not manufacturing drawings. No validated Target gaps, supplier quotes, approved formulas or certified performance.

OPEN THIS PACK
Open drying-rack-specification.html in a browser; all studio images and the dimension reference are included locally. Print it to PDF if needed. The BOM is a spreadsheet-compatible CSV with formula-injection escaping.
Open drying-rack.blend in Blender 5.2+ for the editable studio scene. Materials named HA_body control the main color. The GLB is a portable exterior design study with partCode metadata; studio lighting and procedural textures may differ. Source units are metres and proposed dimensions are millimetres.

COLOR OPTIONS
Sage: #93a183 · assumed color allowance USD 0.00 per kit
Chalk: #e7e3d3 · assumed color allowance USD 0.00 per kit
Clay: #b67e64 · assumed color allowance USD 0.03 per kit
Ink: #24463d · assumed color allowance USD 0.05 per kit
Screen HEX values are visualization references, not Pantone/RAL matches or approved production standards. Color surcharge is a kit-level planning allowance. Approve physical resin and textile samples, gloss and batch color variation.

REBUILD
blender -b --python blender_workshop.py -- --data workshop-data.json --out regenerated

ENGINEERING HANDOFF
No supplier quotations, approved formulas, production drawings, verified Target gaps or certified performance. Exterior dimensions do not resolve internal walls, interfaces, fasteners, mold splits, draft, sealing, assembly or tolerance stacks. The exploded website view is a design-review arrangement, not assembly instructions.

BOM / PRICE BASIS
USD per finished kit. Component unit ranges, labor, packaging, QA, scrap, tooling and freight are engineering allowances. Duty is unknown; landed cost stays uncalculated until entered in the website. Supplier and retailer margins are planning assumptions, not Target requirements. Quantities, tool life, origin, MOQ, refill economics and service availability need supplier validation. The base pack contains default Sage assumptions. Save a configured brief and BOM from the website to retain your changed values.

BENCHMARKS
Brabantia — HangOn drying rack, 25 metres, White
https://www.brabantia.com/uk/hangon-drying-rack-25-metres-white/
Reviewed 2026-11-04: Manufacturer product page reviewed
Displayed reference price; shipping, tax, location and promotions may differ. No checkout or stock confirmation.

Leifheit — Pegasus Family 18m / Pegasus 180 Solid Classic, 81514
https://www.leifheit.com/en-en/standing-dryers/16412/standing-dryer-pegasus-180-solid-classic/81514
Reviewed 2026-11-04: Manufacturer product page reviewed
Price not established for the exact reviewed variant.

NEXT
Develop replaceable rod clips and a visible lock indicator. Folding racks already exist; prove repair speed and stable loading rather than a larger drying-length claim.
Render shows one open configuration. Folding geometry, locking strength, load rating and pinch clearances are unresolved.
Stop condition: Stop for instability, exposed pinch points, coating corrosion or an uneconomic service-part system.
