HOMECARE — WHITE LABEL WORKSHOP
HA-05 · Fragrance-free care trio · Revision A0
Authored 2026-11-04

Industrial-design proposals. Dimensioned exterior mockups, not manufacturing drawings. No validated Target gaps, supplier quotes, approved formulas or certified performance.

OPEN THIS PACK
Open quiet-scent-specification.html in a browser; all studio images and the dimension reference are included locally. Print it to PDF if needed. The BOM is a spreadsheet-compatible CSV with formula-injection escaping.
Open quiet-scent.blend in Blender 5.2+ for the editable studio scene. Materials named HA_body control the main color. The GLB is a portable exterior design study with partCode metadata; studio lighting and procedural textures may differ. Source units are metres and proposed dimensions are millimetres.

COLOR OPTIONS
Sage: #93a183 · assumed color allowance USD 0.00 per kit
Chalk: #e7e3d3 · assumed color allowance USD 0.00 per kit
Clay: #b67e64 · assumed color allowance USD 0.03 per kit
Ink: #24463d · assumed color allowance USD 0.05 per kit
Screen HEX values are visualization references, not Pantone/RAL matches or approved production standards. Color surcharge is a kit-level planning allowance. Approve physical resin and textile samples, gloss and batch color variation.

REBUILD
blender -b --python blender_workshop.py -- --data workshop-data.json --out regenerated

ENGINEERING HANDOFF
No supplier quotations, approved formulas, production drawings, verified Target gaps or certified performance. Exterior dimensions do not resolve internal walls, interfaces, fasteners, mold splits, draft, sealing, assembly or tolerance stacks. The exploded website view is a design-review arrangement, not assembly instructions.

BOM / PRICE BASIS
USD per finished kit. Component unit ranges, labor, packaging, QA, scrap, tooling and freight are engineering allowances. Duty is unknown; landed cost stays uncalculated until entered in the website. Supplier and retailer margins are planning assumptions, not Target requirements. Quantities, tool life, origin, MOQ, refill economics and service availability need supplier validation. The base pack contains default Sage assumptions. Save a configured brief and BOM from the website to retain your changed values.

BENCHMARKS
Blueland — Multi-Surface Cleaner Starter Set
https://www.blueland.com/products/multi-surface-starter-set?plan=one-time
Reviewed 2026-11-04: Manufacturer page reviewed
Displayed reference price; shipping, tax, location and promotions may differ. No checkout or stock confirmation.

Seventh Generation — All Purpose Cleaner – Free & Clear
https://www.seventhgeneration.com/all-purpose-cleaner-free-clear
Reviewed 2026-11-04: Manufacturer page reviewed
Price not established in this review.

NEXT
Test whether consistent labeling makes selection easier. Fragrance-free products themselves are already widely offered.
Fragrance-free is a formulation specification to verify. It does not mean allergy-free, non-toxic or safe for every surface.
Stop condition: Stop if users prefer existing individual items or the bundle duplicates the current offer.
